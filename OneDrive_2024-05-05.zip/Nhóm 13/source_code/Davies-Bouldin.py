import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score

# Đọc dữ liệu
df = pd.read_csv('data.csv')
le = preprocessing.LabelEncoder()
df = df.apply(le.fit_transform)

# Chọn các thuộc tính để phân cụm
X = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth','DiffWalking','Sex','PhysicalActivity','GenHealth','SleepTime','HeartDisease']].values)

# Tách tập huấn luyện và kiểm tra
X_train, X_test = train_test_split(X, test_size=0.1, shuffle=True)

# Sử dụng KMeans với k=4
kmeans_model = KMeans(n_clusters=4, random_state = 42, n_init=10, max_iter= 1000)
kmeans_model.fit(X_train)

# Tính Davies-Bouldin Score cho k=4
db_score = davies_bouldin_score(X_train, kmeans_model.labels_)
print(f"Davies-Bouldin Score for k=4: {db_score}")
