from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
# Đọc dữ liệu từ file CSV
df = pd.read_csv('data.csv')
le = preprocessing.LabelEncoder()
df = df.apply(le.fit_transform)
X = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth','DiffWalking','Sex','PhysicalActivity','GenHealth','SleepTime']].values)
X_train, X_test = train_test_split(X, test_size=0.1, shuffle=False)
# Tìm số cụm tốt nhất
max_k = 10  # Số cụm tối đa cần kiểm tra
best_k = 0
best_silhouette = -1
best_davies_bouldin = float('inf')
for k in range(2, max_k + 1):
    kmeans = KMeans(n_init = 10, random_state=42, n_clusters=k)
    kmeans.fit(X)
    labels = kmeans.labels_

    silhouette = silhouette_score(X, labels)
    davies_bouldin = davies_bouldin_score(X, labels)

    if silhouette > best_silhouette:
        best_k = k
        best_silhouette = silhouette

    if davies_bouldin < best_davies_bouldin:
        best_k = k
        best_davies_bouldin = davies_bouldin

print("Số cụm tốt nhất dựa trên độ đo Silhouette:", best_k)
print("Số cụm tốt nhất dựa trên độ đo Davies-Bouldin:", best_k)