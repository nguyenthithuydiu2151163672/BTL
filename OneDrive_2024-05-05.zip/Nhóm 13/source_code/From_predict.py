import tkinter as tk
from sklearn.metrics import silhouette_score, davies_bouldin_score
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn import preprocessing

class ClusterPredictionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Dự đoán bênh nhân có bị bệnh tim không")
        self.create_widgets()

    def create_widgets(self):
        # Add a new statement Label
        statement_label = tk.Label(self.root, text="Điền thông tin bệnh nhân vào các ô dưới đây", font=("Arial Bold", 12),fg="red")
        statement_label.grid(row=0, column=0, columnspan=2, pady=20)

        # Label và Entry cho các chiều dữ liệu
        self.data_entries = []
        # Label và Entry cho các chiều dữ liệu
        for i, feature in enumerate(['Bệnh nhân có bị bệnh về đường hô hấp không', 'Bệnh nhân có uống chất có cồn hay không', 'Bệnh nhân có bị bệnh về não bộ hay không',
                                     'Chỉ số sức khỏe thể chất', 'Chỉ số sức khỏe tinh thần', 'Bệnh nhân có gặp khó khăn trong việc đi lại không', 'Giới tính',
                                     'Hoạt động thể chất của bệnh nhân có tốt không', 'Sức khoẻ về gen bệnh nhân có gì bất thường không', 'Thời gian ngủ của bênh nhân']):
            label = tk.Label(self.root, text=f"{feature.capitalize()}:")
            label.grid(row=i + 1, column=0, padx=10, pady=5, sticky="w")
            entry = tk.Entry(self.root)
            entry.grid(row=i + 1, column=1, padx=10, pady=5, sticky="e")
            self.data_entries.append(entry)

        # Nút để dự đoán và hiển thị kết quả
        predict_button = tk.Button(self.root, text="Predict", command=self.predict, bg="blue", fg="white")
        predict_button.grid(row=12, column=0, columnspan=2, pady=10)

        # Nút để reset dữ liệu
        reset_button = tk.Button(self.root, text="Reset", command=self.reset, bg="red", fg="white")
        reset_button.grid(row=13, column=0, columnspan=2, pady=10)

        # Label để hiển thị kết quả dự đoán
        self.result_label = tk.Label(self.root, text="", bg="white")
        self.result_label.grid(row=14, column=0, columnspan=2, pady=5)

        # Label để hiển thị độ đo Silhouette Score và Davies-Bouldin Score
        self.silhouette_label = tk.Label(self.root, text="Silhouette Score: ", bg="white")
        self.silhouette_label.grid(row=15, column=0, columnspan=2, pady=5)
        self.davies_bouldin_label = tk.Label(self.root, text="Davies-Bouldin Score: ", bg="white")
        self.davies_bouldin_label.grid(row=16, column=0, columnspan=2, pady=5)

    def predict(self):
        # Lấy dữ liệu từ các ô Entry
        new_sample = [float(entry.get()) for entry in self.data_entries]

        # Dự đoán nhãn của mẫu mới
        predicted_label = kmeans_model.predict([new_sample])[0]

        # Chuyển đổi nhãn dự đoán thành chuỗi kết quả
        result = ""
        if predicted_label == 1:
            result = "Có mắc bệnh tim."
        else:
            result = "Không mắc bệnh tim."

        # Hiển thị kết quả dự đoán
        self.result_label.config(text=f"Predicted Result: {result}")

        # Tính và hiển thị độ đo Silhouette và Davies-Bouldin cho mô hình
        silhouette_avg = silhouette_score(X_train, kmeans_model.labels_)
        davies_bouldin_avg = davies_bouldin_score(X_train, kmeans_model.labels_)

        self.silhouette_label.config(text=f"Silhouette Score: {silhouette_avg:.4f}")
        self.davies_bouldin_label.config(text=f"Davies-Bouldin Score: {davies_bouldin_avg:.4f}")

    def reset(self):
        # Xóa dữ liệu trong các Entry
        for entry in self.data_entries:
            entry.delete(0, tk.END)

        # Reset kết quả và độ đo
        self.result_label.config(text="")
        self.silhouette_label.config(text="Silhouette Score: ")
        self.davies_bouldin_label.config(text="Davies-Bouldin Score: ")

# Sử dụng độ đo dự vào dữ liệu mã hóa
df = pd.read_csv('data.csv')
le = preprocessing.LabelEncoder()
df = df.apply(le.fit_transform)
X = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth','DiffWalking','Sex','PhysicalActivity','GenHealth','SleepTime']].values)
X_train, X_test = train_test_split(X, test_size=0.1, shuffle=False)
# Sử dụng KMeans với k=14
kmeans_model = KMeans(n_clusters=4, random_state=42, n_init=10, max_iter=1000)
kmeans_model.fit(X_train)

# Tạo ứng dụng
root = tk.Tk()
app = ClusterPredictionApp(root)
root.mainloop()
