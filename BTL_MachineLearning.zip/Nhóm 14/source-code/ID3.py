from sklearn import tree
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.metrics import accuracy_score , precision_score , recall_score , f1_score

df = pd.read_csv('data.csv')
X_data = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth',
                      'DiffWalking', 'Sex', 'PhysicalActivity', 'GenHealth', 'SleepTime', 'HeartDisease']].values)

def data_encoder(X):
    encoding_dict = {
        "Yes": 0,
        "No": 1,
        "Female": 2,
        "Male": 3,
        "Very good": 4,
        "Fair": 5,
        "Good": 6,
        "Poor": 7,
        "Excellent": 8
    }
    for i in range(len(X)):
        for j in range(len(X[i])):
            X[i][j] = encoding_dict.get(X[i][j])
    return X

X_data = data_encoder(X_data)

X_train, X_test, y_train, y_test = train_test_split(X_data[:, :10], X_data[:, 10].astype(int),
                                                    test_size=0.3, shuffle=True)

clf = tree.DecisionTreeClassifier(criterion='entropy',max_depth=9)
clf = clf.fit(X_train, y_train)
y_predict = clf.predict(X_test)

print('Tỷ lệ dự đoán đúng theo accuracy là : ',accuracy_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo recall là : ',recall_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo precision là : ',precision_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo F1 là : ',f1_score(y_test,y_predict))
