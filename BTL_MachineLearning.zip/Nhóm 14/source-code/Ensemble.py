import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import  StackingClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder


data = pd.read_csv('data.csv')
data = data.apply(LabelEncoder().fit_transform)

dt_Train, dt_Test = train_test_split(data, test_size= 0.3, shuffle=True)
X_train = dt_Train.iloc[:, 1:10]
y_train = dt_Train.iloc[:, -1]
X_test = dt_Test.iloc[:, 1:10]
y_test = dt_Test.iloc[:, -1]

estimators = [('perceptron', Perceptron(alpha= 0.02, tol = 0.00001, max_iter=1000)),
              ('id3', DecisionTreeClassifier(criterion='entropy', splitter='best', min_samples_split=10, min_samples_leaf=10)),
              ('mlp',MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=1000))]


stacking_model = StackingClassifier(estimators=estimators)
stacking_model.fit(X_train, y_train)
stacking_predictions = stacking_model.predict(X_test)
stacking_accuracy = accuracy_score(y_test, stacking_predictions)
print("Stacking Classifier Accuracy:", stacking_accuracy)