import numpy as np


class Perceptron:
    def __init__(self, learning_rate=1, n_iterations=1000): #Khởi tạo hàm
        self.learning_rate = learning_rate
        self.n_iterations = n_iterations
        self.weights = None
        self.bias = None


    def biasTrick(self, X): #định nghĩa thêm hệ số tự do b
        num_rows_X_test = X.shape[0]
        #thêm một cột bằng 1 vào đầu mỗi mẫu trong X để biểu diễn hệ số tự do trong phép tính.
        new_array_X_test = np.ones((num_rows_X_test, 1))
        X = np.hstack([new_array_X_test.reshape(-1, 1), X])
        return X

    def fit(self, X, y): #định nghĩa hàm train cho các tập dữ liệu
        X = np.array(self.biasTrick(X))#truyền vào tham số tự do đã được định nghĩa ở trên
        y = np.where(y == 1, 1, -1)# chuyển tập y thành 1 và -1 để phân chia thành 2 lớp
        y = np.array(y)
        self.bias = 0
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        # self.weights = [2.,2.,-1.,-2.,-2., 3.,4.]
        for _ in range(self.n_iterations):# vòng for để điều chỉnh và cập nhật tham số weight sao cho không còn dữ liệu lỗi
            check = 0
            for i in range(n_samples):
                if (y[i] * X[i] @ self.weights) <= 0:
                    # if(y[i] * X[i]@self.weights + self.bias)<=0:
                    self.weights = self.weights + self.learning_rate * y[i] * X[i]
                    # self.bias = self.bias + self.learning_rate * y[i]
                    check += 1
            if check == 0:
                break
        return self.weights #trả về giá trị w tối ưu nhất

    def predict(self, X): #hàm dự đoán nhãn 
        X = np.array(self.biasTrick(X)) #vẫn truyền cho X tham số tự do
        linear_output = np.dot(X, self.weights) + self.bias # nhân với tham số weight đã tìm được và cộng với hệ số tự do để tìm ra giá trị dự đoán
        predictions = np.where(linear_output > 0, 1, 0)
        return predictions#trả về giá trị dự đoán
    # np.array([2.,2.,-1.,-2.,-2., 3.,4.])
