from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import Perceptron
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score

df = pd.read_csv('data.csv')
le = preprocessing.LabelEncoder()
df = df.apply(le.fit_transform)
X = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth',
                      'DiffWalking', 'Sex', 'PhysicalActivity', 'GenHealth', 'SleepTime']].values)
y = np.array(df['HeartDisease'])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3 , shuffle = False)

#id3
id3 = DecisionTreeClassifier(criterion='entropy',max_depth=9)
id3.fit(X_train, y_train)

#form
form = Tk()
form.title("Dự đoán khả năng mắc bệnh tim:")
form.geometry("800x700")



lable_ten = Label(form, text = "Nhập thông tin chỉ số của bệnh nhân:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_Asthma = Label(form, text = " Bệnh nhân có bị bệnh về đường hô hấp không:")
lable_Asthma.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_Asthma = Entry(form)
textbox_Asthma.grid(row = 2, column = 2)

lable_AlcoholDrinking = Label(form, text = "Bệnh nhân có sử dụng chất có cồn hay không:")
lable_AlcoholDrinking.grid(row = 3, column = 1, pady = 10)
textbox_AlcoholDrinking = Entry(form)
textbox_AlcoholDrinking.grid(row = 3, column = 2)

lable_Stroke = Label(form, text = "Bệnh nhân có bị bệnh về não bộ hay không:")
lable_Stroke.grid(row = 4, column = 1,pady = 10)
textbox_Stroke = Entry(form)
textbox_Stroke.grid(row = 4, column = 2)

lable_PhysicalHealth = Label(form, text = "Chỉ số sức khỏe thể chất:")
lable_PhysicalHealth.grid(row = 5, column = 1, pady = 10)
textbox_PhysicalHealth = Entry(form)
textbox_PhysicalHealth.grid(row = 5, column = 2)

lable_MentalHealth = Label(form, text = "Chỉ số sức khỏe tinh thần:")
lable_MentalHealth.grid(row = 6, column = 1, pady = 10 )
textbox_MentalHealth = Entry(form)
textbox_MentalHealth.grid(row = 6, column = 2)

lable_DiffWalking = Label(form, text = "Bệnh nhân có gặp khó khăn trong việc đi lại không:")
lable_DiffWalking.grid(row = 7, column = 1, pady = 10 )
textbox_DiffWalking = Entry(form)
textbox_DiffWalking.grid(row = 7, column = 2)

lable_Sex = Label(form, text = "Giới tính:")
lable_Sex.grid(row = 8, column = 1, pady = 10 )
textbox_Sex = Entry(form)
textbox_Sex.grid(row = 8, column = 2)

lable_PhysicalActivity = Label(form, text = "Hoạt động thể chất của bệnh nhân có tốt không:")
lable_PhysicalActivity.grid(row = 9, column = 1, pady = 10 )
textbox_PhysicalActivity = Entry(form)
textbox_PhysicalActivity.grid(row = 9, column = 2)

lable_GenHealth = Label(form, text = "Sức khoẻ về gen bệnh nhân có gì bất thường không:")
lable_GenHealth.grid(row = 10, column = 1, pady = 10 )
textbox_GenHealth = Entry(form)
textbox_GenHealth.grid(row = 10, column = 2)

lable_SleepTime = Label(form, text = "Thời gian ngủ của bênh nhân:")
lable_SleepTime.grid(row = 11, column = 1, pady = 10 )
textbox_SleepTime = Entry(form)
textbox_SleepTime.grid(row = 11, column = 2)

#id3
#dudoanid3test
y_id3 = id3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=1, row=13)
lbl3.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"Acuracy: "+str(accuracy_score(y_test, y_id3)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_id3, average='macro')*100)+"%"+'\n')
def dudoanid3():
    Asthma = textbox_Asthma.get()
    AlcoholDrinking = textbox_AlcoholDrinking.get()
    Stroke = textbox_Stroke.get()
    PhysicalHealth = textbox_PhysicalHealth.get()
    MentalHealth =textbox_MentalHealth.get()
    DiffWalking = textbox_DiffWalking.get()
    Sex =textbox_Sex.get()
    PhysicalActivity = textbox_PhysicalActivity.get()
    GenHealth = textbox_GenHealth.get()
    SleepTime = textbox_SleepTime.get()
    if((Asthma == '') or (AlcoholDrinking == '') or (Stroke == '') or (PhysicalHealth == '') or (MentalHealth == '')or (DiffWalking == '') or (Sex == '')
    or (PhysicalActivity == '') or (GenHealth == '') or (SleepTime == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([Asthma, AlcoholDrinking, Stroke, PhysicalHealth, MentalHealth,
                      DiffWalking, Sex, PhysicalActivity,GenHealth,SleepTime]).reshape(1, -1)
        y_kqua = id3.predict(X_dudoan)
        if y_kqua[0] == 0:
            lbl2.configure(text="Không mắc bệnh tim")
        else:
            lbl2.configure(text="Có khả năng mắc bệnh tim")

button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanid3)
button_id3.grid(row = 13, column = 2, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=3, row=13)

def khanangid3():
    y_id3 = id3.predict(X_test)
    dem=0
    for i in range (len(y_id3)):
        if(y_id3[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_id3))*100
    lbl3.configure(text= count)
button_id31 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangid3)
button_id31.grid(row = 14, column = 2, padx = 20)
lbl3 = Label(form, text="...")
lbl3.grid(column=3, row=14)


form.mainloop()
