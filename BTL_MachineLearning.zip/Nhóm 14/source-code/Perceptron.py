import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from ClassPerceptron import Perceptron
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score , precision_score , recall_score , f1_score

df = pd.read_csv('data.csv')
X_data = np.array(df[['Asthma', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth','DiffWalking','Sex','PhysicalActivity','GenHealth','SleepTime','HeartDisease']].values)

def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 11):
            if (j[k] == "Yes"):
                j[k] = 0
            elif (j[k] == "No"):
                j[k] = 1
            elif (j[k] == "Female"):
                j[k] = 2
            elif (j[k] == "Male"):
                j[k] = 3
            elif (j[k] == "Very good"):
                j[k] = 4
            elif (j[k] == "Fair"):
                j[k] = 5
            elif (j[k] == "Good"):
                j[k] = 6
            elif (j[k] == "Poor"):
                j[k] = 7
            elif (j[k] == "Excellent"):
                j[k] = 8
    return X

data = data_encoder(X_data)

dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=True)

X_train = dt_Train[:, :10]
y_train = dt_Train[:, 10]
y_train = y_train.astype('int')
X_test = dt_Test[:, :10]
y_test = dt_Test[:, 10]
y_test = y_test.astype('int')

pla = Perceptron()
pla.fit(X_train, y_train)
y_predict = pla.predict(X_test)

print('Tỷ lệ dự đoán đúng theo accuracy là : ',accuracy_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo recall là : ',recall_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo precision là : ',precision_score(y_test,y_predict))
print('Tỷ lệ dự đoán đúng theo F1 là : ',f1_score(y_test,y_predict))
